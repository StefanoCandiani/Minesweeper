Name: Stefano Candiani
Section: 10792
UFL email: stefanocandiani@ufl.edu
System: Apple M1 (Sonoma 14.2.1)
Compiler: g++ (Apple Clang Version 15.0.0)
SFML version: 2.6.1
IDE: CLIon (V. 2023.3.4)
Other notes: None